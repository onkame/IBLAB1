﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;

namespace IB_LR_1
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {

        string connectionString;
        
        public Window2()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            IB_LR_1.IB_LR_1DataSet iB_LR_1DataSet = ((IB_LR_1.IB_LR_1DataSet)(this.FindResource("iB_LR_1DataSet")));
            // Загрузить данные в таблицу UserData. Можно изменить этот код как требуется.
            IB_LR_1.IB_LR_1DataSetTableAdapters.UserDataTableAdapter iB_LR_1DataSetUserDataTableAdapter = new IB_LR_1.IB_LR_1DataSetTableAdapters.UserDataTableAdapter();
            iB_LR_1DataSetUserDataTableAdapter.Fill(iB_LR_1DataSet.UserData);
            System.Windows.Data.CollectionViewSource userDataViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("userDataViewSource")));
            userDataViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int check = 0;
            string s1 = loginTextBox.Text;

            if (s1.Count() < 4 || s1.Count() >= 5)
            {
                MessageBox.Show("Логин должен состоять из 4 цифр!");
                check = 1;
                return;
            }
            for (int i = 0; i < s1.Length; i++)
            {
                if (!(s1[i] >= '0' && s1[i] <= '9'))
                {
                    MessageBox.Show("Логин должен состоять из 4 цифр!");
                    check = 1;
                    return;
                }
            }

            string s2 = passwordTextBox.Text;

            if (s2.Count() < 6 || s2.Count() >= 7)
            {
                MessageBox.Show("Пароль должен состоять из 6 символов!");
                check = 1;
                return;
            }
            for (int i = 0; i < s2.Length; i++)
            {
                if (!((s2[i] >= 'A' && s2[i] <= 'Z') || (s2[i] >= 'a' && s2[i] <= 'z') || (s2[i] >= '0' && s2[i] <= '9')))
                {
                    MessageBox.Show("Пароль должен содержать только буквы и цифры!");
                    check = 1;
                    return;
                }
            }

            if (check == 0)
            {
                SqlConnection connection = null;
                connectionString = ConfigurationManager.ConnectionStrings["IB_LR_1.Properties.Settings.IB_LR_1ConnectionString"].ConnectionString;
                string query = "SELECT Name FROM UserData WHERE (Login = " + loginTextBox.Text + ") and (Password = '" + passwordTextBox.Text + "')";
                try
                {
                    using (connection = new SqlConnection(connectionString))
                    {
                        var command1 = new SqlCommand(query, connection);
                        connection.Open();
                        command1.ExecuteNonQuery();
                        object result = command1.ExecuteScalar();
                        if (result == null) MessageBox.Show("Учетная запись не найдена");
                        else
                        {
                            MessageBox.Show("Добро пожаловать, " + result.ToString());
                            this.Hide();
                            Window3 b = new Window3();
                            b.Show();   
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (connection != null)
                        connection.Close();
                }
            }
            
        }

    }
}
