﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MessageBox = System.Windows.MessageBox;

namespace IB_LR_1
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        string connectionString;
        string connectionString1;
        SqlDataAdapter adapter;
        SqlDataAdapter adapter1;

        public Window1()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            IB_LR_1.IB_LR_1DataSet iB_LR_1DataSet = ((IB_LR_1.IB_LR_1DataSet)(this.FindResource("iB_LR_1DataSet")));
            // Загрузить данные в таблицу UserData. Можно изменить этот код как требуется.
            IB_LR_1.IB_LR_1DataSetTableAdapters.UserDataTableAdapter iB_LR_1DataSetUserDataTableAdapter = new IB_LR_1.IB_LR_1DataSetTableAdapters.UserDataTableAdapter();
            iB_LR_1DataSetUserDataTableAdapter.Fill(iB_LR_1DataSet.UserData);
            System.Windows.Data.CollectionViewSource userDataViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("userDataViewSource")));
            userDataViewSource.View.MoveCurrentToFirst();
        }

        

        private void loginTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
           string s = loginTextBox.Text;
            
            if (s.Count() < 4 || s.Count() >= 5)
            {
                TextBlock1.Text = "Логин должен состоять из 4 цифр!";
            }
            else
            {
                TextBlock1.Text = "";
            }
            for (int i = 0; i < s.Length; i++)
            {
                if (!(s[i] >= '0' && s[i] <= '9'))
                {
                    TextBlock1.Text = "Логин должен состоять из 4 цифр!";
                }
            }
        }


        private void passwordTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

            string s = passwordTextBox.Text;

            if (s.Count() < 6 || s.Count() >= 7)
            {
                TextBlock2.Text = "Пароль должен содержать 6 символов!";
            }
            else
            {
                TextBlock2.Text = "";
            }
            for (int i = 0; i < s.Length; i++)
            {
                if (!((s[i] >= 'A' && s[i] <= 'Z') || (s[i] >= 'a' && s[i] <= 'z') || (s[i] >= '0' && s[i] <= '9')))
                {
                    TextBlock2.Text = "Пароль должен содержать только буквы и цифры!";
                }
            }
        }

        private void phoneNumberTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string s = phoneNumberTextBox.Text;

            if (s.Count() != 0)
            {

                if (s.Count() < 11 || s.Count() >= 12)
                {
                    TextBlock3.Text = "Телефонный номер состоит из 11 цифр!";
                }
                else
                {
                    TextBlock3.Text = "";
                }
                for (int i = 0; i < s.Length; i++)
                {
                    if (!(s[0] == '7'))
                    {
                        TextBlock3.Text = "Введите телефонный номер, начиная с 7 без дополнительных символов";
                    }
                    if (!(s[i] >= '0' && s[i] <= '9'))
                    {
                        TextBlock3.Text = "Введите телефонный номер, начиная с 7 без дополнительных символов";
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //.................................
            //.   Проверка введенных данных   .
            //.................................

            int check = 0;

            string s1 = loginTextBox.Text;

            if (s1.Count() < 4 || s1.Count() >= 5)
            {
                MessageBox.Show("Логин должен состоять из 4 цифр!");
                check = 1;
                return;
            }
            for (int i = 0; i < s1.Length; i++)
            {
                if (!(s1[i] >= '0' && s1[i] <= '9'))
                {
                    MessageBox.Show("Логин должен состоять из 4 цифр!");
                    check = 1;
                    return;
                }
            }

            string s2 = passwordTextBox.Text;

            if (s2.Count() < 6 || s2.Count() >= 7)
            {
                MessageBox.Show("Пароль должен состоять из 6 символов!");
                check = 1;
                return;
            }
            for (int i = 0; i < s2.Length; i++)
            {
                if (!((s2[i] >= 'A' && s2[i] <= 'Z') || (s2[i] >= 'a' && s2[i] <= 'z') || (s2[i] >= '0' && s2[i] <= '9')))
                {
                    MessageBox.Show("Пароль должен содержать только буквы и цифры!");
                    check = 1;
                    return;
                }
            }

            string s3 = phoneNumberTextBox.Text;

            if (s3.Count() != 0)
            {
                if (s3.Count() < 11 || s3.Count() >= 12)
                {
                    MessageBox.Show("Телефонный номер состоит из 11 цифр!");
                    check = 1;
                    return;
                }
                for (int i = 0; i < s3.Length; i++)
                {
                    if (!(s3[0] == '7'))
                    {
                        MessageBox.Show("Введите телефонный номер, начиная с 7");
                        check = 1;
                        return;
                    }
                    if (!(s3[i] >= '0' && s3[i] <= '9'))
                    {
                        MessageBox.Show("Введите телефонный номер не используя дополнительных символов");
                        check = 1;
                        return;
                    }
                }
            }

            SqlConnection connection = null;
            connectionString = ConfigurationManager.ConnectionStrings["IB_LR_1.Properties.Settings.IB_LR_1ConnectionString"].ConnectionString;
            string query1 = "SELECT * FROM UserData WHERE (Login = " + loginTextBox.Text + ")";
            try
            {
                using (connection = new SqlConnection(connectionString))
                {
                    var command1 = new SqlCommand(query1, connection);
                    connection.Open();
                    command1.ExecuteNonQuery();
                    adapter = new SqlDataAdapter(command1);
                    object result = command1.ExecuteScalar();
                    if (result != null)
                    {
                        MessageBox.Show("Логин занят, введите другой");
                        check = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }

            
            //.............................
            //.   Если данные корректны   .
            //.............................

            if (check == 0) { 

                // Создаём объект процесса.
                Process p = new Process();
                // Перенаправляем поток вывода консоли в нашу программу.
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardOutput = true;
                // Отключаем показ окна консоли.
                p.StartInfo.CreateNoWindow = true;
                // Указываем исполняемый файл приложения или «cmd», если требуется запустить командную строку.
                p.StartInfo.FileName = "wmic";
                // Передаём собственно консольную команду  с параметрами.
                p.StartInfo.Arguments = "csproduct get UUID";
                // Запускаем процесс.
                p.Start();
                string output = p.StandardOutput.ReadToEnd();
                // "UUID                                  \r\r\n34444335-3733-4A30-5331-8CDCD47F7BA0  \r\r\n\r\r\n"
                p.WaitForExit();
                string uuidstring = output.Substring(41);
                uuidstring = uuidstring.Remove(uuidstring.Length - 8, 8);


                SqlConnection connection3 = null;
                connectionString1 = ConfigurationManager.ConnectionStrings["IB_LR_1.Properties.Settings.IB_LR_1ConnectionString"].ConnectionString;
                string query = "UPDATE UserData SET Login = " + loginTextBox.Text + ","
                    +" Password = '" + passwordTextBox.Text + "'," +
                    " Name = '" + nameTextBox.Text + "'," +
                    " Email = '" + emailTextBox.Text + "'," +
                    " PhoneNumber = " + phoneNumberTextBox.Text + "," +
                    " Address = '" + addressTextBox.Text + "' " +
                    "WHERE UUID = '" + uuidstring + "'";
                
                try
                {
                    using (connection3 = new SqlConnection(connectionString1))
                    {
                        var command2 = new SqlCommand(query, connection3);
                        connection3.Open();
                        command2.ExecuteNonQuery();
                        adapter1 = new SqlDataAdapter(command2);
                        MessageBox.Show("Вы успешно зарегистрированы!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (connection3 != null)
                        connection3.Close();
                }

                this.Hide();
                Window2 b = new Window2();
                b.Show();
            }
        }

        private void nameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
