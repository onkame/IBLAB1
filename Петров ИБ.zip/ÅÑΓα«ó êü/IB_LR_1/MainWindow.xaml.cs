﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IB_LR_1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string connectionString;

        public MainWindow()
        {
            InitializeComponent(); 
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //................................
            //.   Получаем UUID из системы   .
            //................................

            // Создаём объект процесса.
            Process p = new Process();
                    // Перенаправляем поток вывода консоли в нашу программу.
                    p.StartInfo.UseShellExecute = false;
                    p.StartInfo.RedirectStandardOutput = true;
                    // Отключаем показ окна консоли.
                    p.StartInfo.CreateNoWindow = true;
                    // Указываем исполняемый файл приложения или «cmd», если требуется запустить командную строку.
                    p.StartInfo.FileName = "wmic";
                    // Передаём собственно консольную команду  с параметрами.
                    p.StartInfo.Arguments = "csproduct get UUID";
            // Запускаем процесс.
            p.Start();
            string output = p.StandardOutput.ReadToEnd();
            // "UUID                                  \r\r\nA970A935-AD5A-0243-8E63-5004E6D831BE  \r\r\n\r\r\n"
            p.WaitForExit();
            string uuidstring = output.Substring(41);
            uuidstring = uuidstring.Remove(uuidstring.Length - 8, 8);

            
            //................................
            //.     Сравниваем UUID с БД     .
            //................................

            int res = 0;
            SqlConnection connection1 = null;
            connectionString = ConfigurationManager.ConnectionStrings["IB_LR_1.Properties.Settings.IB_LR_1ConnectionString"].ConnectionString;
            string query = "SELECT COUNT(*) FROM UserData WHERE exists(SELECT * FROM UserData WHERE (UserData.UUID = '"+ uuidstring + "'))";
            try
            {
                using (connection1 = new SqlConnection(connectionString))
                {
                    var command1 = new SqlCommand(query, connection1);
                    connection1.Open();
                    command1.ExecuteNonQuery();
                    string result = command1.ExecuteScalar().ToString();
                    res = int.Parse(result);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection1 != null)
                    connection1.Close();
            }

            if (res == 0)
            {
                MessageBox.Show("Вашего компьютера нет в базе!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Ваш компьютер прошел проверку!");
                //........................................................
                //.     Проверка наличия учетной записи пользователя     .
                //........................................................

                int reg = 0;
                SqlConnection connection2 = null;
                connectionString = ConfigurationManager.ConnectionStrings["IB_LR_1.Properties.Settings.IB_LR_1ConnectionString"].ConnectionString;
                //..................................................
                //.     Проверяем, пуст ли логин под этим UUID     .
                //..................................................
                string query2 = "SELECT COUNT(*) FROM UserData WHERE (UserData.UUID = '" + uuidstring + "') and NOT(UserData.Login is NULL)";
                try
                {
                    using (connection2 = new SqlConnection(connectionString))
                    {
                        var command2 = new SqlCommand(query2, connection2);
                        connection2.Open();
                        command2.ExecuteNonQuery();
                        string result2 = command2.ExecuteScalar().ToString();
                        reg = int.Parse(result2);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (connection2 != null)
                        connection2.Close();
                }

                //................................................
                //.     Если пользователь не зарегистрирован     .
                //................................................
                if (reg == 0){
                    this.Hide();
                    Window1 a = new Window1();
                    a.Show();
                }
                //.............................................
                //.     Если пользователь зарегистрирован     .
                //.............................................
                else
                {
                    this.Hide();
                    Window2 b = new Window2();
                    b.Show();
                }
            }


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
    }
}
