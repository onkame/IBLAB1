﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IB_LR_1
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        string connectionString;
        SqlDataAdapter adapter;

        public Window3()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            IB_LR_1.IB_LR_1DataSet iB_LR_1DataSet = ((IB_LR_1.IB_LR_1DataSet)(this.FindResource("iB_LR_1DataSet")));
            // Загрузить данные в таблицу UserData. Можно изменить этот код как требуется.
            IB_LR_1.IB_LR_1DataSetTableAdapters.UserDataTableAdapter iB_LR_1DataSetUserDataTableAdapter = new IB_LR_1.IB_LR_1DataSetTableAdapters.UserDataTableAdapter();
            iB_LR_1DataSetUserDataTableAdapter.Fill(iB_LR_1DataSet.UserData);
            System.Windows.Data.CollectionViewSource userDataViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("userDataViewSource")));
            userDataViewSource.View.MoveCurrentToFirst();
            // Загрузить данные в таблицу MessageTable. Можно изменить этот код как требуется.
            IB_LR_1.IB_LR_1DataSetTableAdapters.MessageTableTableAdapter iB_LR_1DataSetMessageTableTableAdapter = new IB_LR_1.IB_LR_1DataSetTableAdapters.MessageTableTableAdapter();
            iB_LR_1DataSetMessageTableTableAdapter.Fill(iB_LR_1DataSet.MessageTable);
            System.Windows.Data.CollectionViewSource messageTableViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("messageTableViewSource")));
            messageTableViewSource.View.MoveCurrentToFirst();
            // Загрузить данные в таблицу Note. Можно изменить этот код как требуется.
            IB_LR_1.IB_LR_1DataSetTableAdapters.NoteTableAdapter iB_LR_1DataSetNoteTableAdapter = new IB_LR_1.IB_LR_1DataSetTableAdapters.NoteTableAdapter();
            iB_LR_1DataSetNoteTableAdapter.Fill(iB_LR_1DataSet.Note);
            System.Windows.Data.CollectionViewSource noteViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("noteViewSource")));
            noteViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string s = MessageTextBox.Text;

            if (s.Count() <= 59)
            {
                Process p = new Process();
                // Перенаправляем поток вывода консоли в нашу программу.
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardOutput = true;
                // Отключаем показ окна консоли.
                p.StartInfo.CreateNoWindow = true;
                // Указываем исполняемый файл приложения или «cmd», если требуется запустить командную строку.
                p.StartInfo.FileName = "wmic";
                // Передаём собственно консольную команду  с параметрами.
                p.StartInfo.Arguments = "csproduct get UUID";
                // Запускаем процесс.
                p.Start();
                string output = p.StandardOutput.ReadToEnd();
                // "UUID                                  \r\r\nA970A935-AD5A-0243-8E63-5004E6D831BE  \r\r\n\r\r\n"
                p.WaitForExit();
                string uuidstring = output.Substring(41);
                uuidstring = uuidstring.Remove(uuidstring.Length - 8, 8);

                SqlConnection connection = null;
                connectionString = ConfigurationManager.ConnectionStrings["IB_LR_1.Properties.Settings.IB_LR_1ConnectionString"].ConnectionString;
                string query1 = "UPDATE MessageTable SET Message = '" + MessageTextBox.Text + "'" +
                    "WHERE UUID = '" + uuidstring + "'";
                string query2 = "SELECT UserData.Name AS Имя, MessageTable.Message AS Пишет " +
                "FROM  MessageTable INNER JOIN " +
                "UserData ON MessageTable.UUID = UserData.UUID";
                try
                {
                    using (connection = new SqlConnection(connectionString))
                    {
                        var command1 = new SqlCommand(query1, connection);
                        var command2 = new SqlCommand(query2, connection);
                        connection.Open();
                        command1.ExecuteNonQuery();
                        adapter = new SqlDataAdapter(command2);
                        DataTable tableM = new DataTable();
                        adapter.Fill(tableM);
                        MesGrid.ItemsSource = tableM.DefaultView;
                        MessageBox.Show("Вы добавили запись в блокнот");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (connection != null)
                        connection.Close();
                }
            } 
            else
            { MessageBox.Show("Слишком длинная запись!");  }

        }

    }
}
